package com.ujwal;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileProcessingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
