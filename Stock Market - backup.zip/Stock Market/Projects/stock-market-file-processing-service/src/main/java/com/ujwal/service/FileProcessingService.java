package com.ujwal.service;

import com.ujwal.model.FileRecord;

public interface FileProcessingService {

	public void processFile(FileRecord record);
	
}
