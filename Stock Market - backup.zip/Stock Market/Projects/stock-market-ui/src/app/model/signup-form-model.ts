export interface SignupFormModel {
    username: String,
    password: String,
    email: String
}
