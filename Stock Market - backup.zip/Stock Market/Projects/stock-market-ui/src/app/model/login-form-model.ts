export interface LoginFormModel {
    username: String,
    password: String
}
