export interface StockPrice {
    price: number
    timestamp: Date
}
