import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-company-dialog',
  templateUrl: './compare-company-dialog.component.html',
  styleUrls: ['./compare-company-dialog.component.css']
})
export class CompareCompanyDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
