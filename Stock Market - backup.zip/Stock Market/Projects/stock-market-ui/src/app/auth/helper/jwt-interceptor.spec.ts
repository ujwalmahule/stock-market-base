import { JwtInterceptor } from './jwt-interceptor';

describe('JwtInterceptor', () => {
  it('should create an instance', () => {
    expect(new JwtInterceptor()).toBeTruthy();
  });
});
