export interface BodyComponent {
}
